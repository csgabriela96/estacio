package cadastroclientv2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class CadastroClientV2 {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 4321;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Conectado ao servidor!");

            Object welcomeMessage = in.readObject();
            if (welcomeMessage instanceof String) {
                System.out.println((String) welcomeMessage);
            }

            while (true) {
                System.out.println("\nEscolha uma opção:");
                System.out.println("L - Listar produtos");
                System.out.println("E - Entrada de produto");
                System.out.println("S - Saída de produto");
                System.out.println("X - Finalizar");
                System.out.print("> ");

                String command = scanner.nextLine().trim().toUpperCase();
                if (command.equals("X")) {
                    System.out.println("Finalizando conexão...");
                    break;
                }

                out.writeObject(command);
                out.flush();

                if (command.equals("E") || command.equals("S")) {
                    System.out.print("ID da pessoa: ");
                    int idPessoa = scanner.nextInt();
                    out.writeObject(idPessoa);
                    out.flush();

                    System.out.print("ID do produto: ");
                    int idProduto = scanner.nextInt();
                    out.writeObject(idProduto);
                    out.flush();

                    System.out.print("Quantidade: ");
                    int quantidade = scanner.nextInt();
                    out.writeObject(quantidade);
                    out.flush();

                    System.out.print("Valor unitário: ");
                    scanner.nextLine();
                    String valorUnitario = scanner.nextLine(); 
                    out.writeObject(valorUnitario);
                    out.flush();
                }

                try {
                    Object response = in.readObject();
                    if (response instanceof String) {
                        System.out.println("SERVIDOR: " + response);
                    }
                } catch (EOFException e) {
                    System.err.println("Servidor encerrou a conexão.");
                    break;
                }
            }

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erro na comunicação: " + e.getMessage());
        }
    }
}
