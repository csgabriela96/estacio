/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastroclientv2;

import javax.swing.*;

public class SaidaFrame extends JDialog {
    public JTextArea texto;

    public SaidaFrame() {
        setTitle("Mensagens do Servidor");
        setBounds(100, 100, 400, 300); 
        setModal(false); 

        texto = new JTextArea();
        texto.setEditable(false); 
        add(new JScrollPane(texto)); 

        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE); 
    }

    public void adicionarMensagem(String mensagem) {
        texto.append(mensagem + "\n");
    }
}