/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastroclientv2;

import javax.swing.*;
import java.io.ObjectInputStream;
import java.util.List;
import model.Produto;

public class ThreadClient extends Thread {
    private ObjectInputStream entrada;
    private JTextArea textArea;

    public ThreadClient(ObjectInputStream entrada, JTextArea textArea) {
        this.entrada = entrada;
        this.textArea = textArea;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Object recebido = entrada.readObject();
                
                if (recebido instanceof String) {
                    SwingUtilities.invokeLater(() -> textArea.append((String) recebido + "\n"));
                } else if (recebido instanceof List<?>) {
                    List<?> lista = (List<?>) recebido;
                    SwingUtilities.invokeLater(() -> {
                        textArea.append("Lista de produtos recebida:\n");
                        for (Object obj : lista) {
                            if (obj instanceof Produto) {
                                Produto produto = (Produto) obj;
                                textArea.append(produto.getNome() + " - Quantidade: " + produto.getQuantidade() + "\n");
                            }
                        }
                    });
                }
            }
        } catch (Exception e) {
            SwingUtilities.invokeLater(() -> textArea.append("Erro na comunicação: " + e.getMessage() + "\n"));
        }
    }
}