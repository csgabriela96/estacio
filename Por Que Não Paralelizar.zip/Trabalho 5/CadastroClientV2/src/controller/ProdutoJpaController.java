/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import javax.persistence.*;
import model.Produto;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

public class ProdutoJpaController {
    private EntityManagerFactory emf;

    public ProdutoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
public void edit(Produto produto) {
        EntityManager em = getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.merge(produto);
            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw new RuntimeException("Erro ao editar produto: " + e.getMessage(), e);
        } finally {
            em.close();
        }
    }
    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }
    public Produto findProduto(int id) {
    EntityManager em = getEntityManager();
    try {
        return em.find(Produto.class, id);
    } finally {
        em.close();
    }
}

    public List<Produto> findProdutoEntities() {
        EntityManager em = getEntityManager();
        try {
            return em.createQuery("SELECT p FROM Produto p", Produto.class).getResultList();
        } finally {
            em.close();
        }
    }
}
