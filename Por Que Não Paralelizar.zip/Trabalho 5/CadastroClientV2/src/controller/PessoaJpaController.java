/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import model.PessoasFisicas;
import model.PessoasJuridicas;

public class PessoaJpaController {
    private EntityManagerFactory emf;

    public PessoaJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public PessoasFisicas findPessoaFisica(int id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(PessoasFisicas.class, id);
        } finally {
            em.close();
        }
    }

    public PessoasJuridicas findPessoaJuridica(int id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(PessoasJuridicas.class, id);
        } finally {
            em.close();
        }
    }
}
