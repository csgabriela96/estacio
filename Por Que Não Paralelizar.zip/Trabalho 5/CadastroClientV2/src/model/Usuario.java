/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.*;
import controller.UsuarioJpaController;
import java.util.List;
import javax.persistence.TypedQuery;

@Entity
@Table(name = "Usuario")
@NamedQueries({
    @NamedQuery(name = "Usuario.findAll", query = "SELECT u FROM Usuario u"),
    @NamedQuery(name = "Usuario.findByLogin", query = "SELECT u FROM Usuario u WHERE u.email = :email AND u.senha = :senha") 
})
public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_Usuario") 
    private Integer idUsuario;

    @Basic(optional = false)
    @Column(name = "Nome")
    private String nome;

    @Basic(optional = false)
    @Column(name = "Email") 
    private String email;

    @Basic(optional = false)
    @Column(name = "Senha")
    private String senha;

    @Basic(optional = false)
    @Column(name = "Tipo")
    private String tipo;

    @Column(name = "Data_Cadastro")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCadastro;

    public Usuario() {}

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public Date getDataCadastro() { return dataCadastro; }
    public void setDataCadastro(Date dataCadastro) { this.dataCadastro = dataCadastro; }
public static void main(String[] args) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("CadastroServerPU");
    UsuarioJpaController usuarioController = new UsuarioJpaController(emf);

    List<Usuario> usuarios = usuarioController.findUsuarioEntities();
    if (usuarios.isEmpty()) {
        System.out.println("Nenhum usuário encontrado no banco de dados.");
    } else {
        System.out.println("Usuários encontrados:");
        for (Usuario u : usuarios) {
            System.out.println("ID: " + u.getIdUsuario() + ", Nome: " + u.getNome() + ", Email: " + u.getEmail());
        }
    }


    Usuario usuario = usuarioController.findUsuario("joao@email.com", "123456");
    if (usuario == null) {
        System.out.println("Usuário não encontrado ou senha incorreta.");
    } else {
        System.out.println("Login bem-sucedido: " + usuario.getNome());
    }

    emf.close();
}
}
