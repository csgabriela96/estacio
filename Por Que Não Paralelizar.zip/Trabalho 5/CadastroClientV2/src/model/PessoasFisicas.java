/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Gabriela
 */
@Entity
@Table(name = "pessoas_fisicas")
@NamedQueries({
    @NamedQuery(name = "PessoasFisicas.findAll", query = "SELECT p FROM PessoasFisicas p"),
    @NamedQuery(name = "PessoasFisicas.findByIdPessoaFisica", query = "SELECT p FROM PessoasFisicas p WHERE p.idPessoaFisica = :idPessoaFisica"),
    @NamedQuery(name = "PessoasFisicas.findByNome", query = "SELECT p FROM PessoasFisicas p WHERE p.nome = :nome"),
    @NamedQuery(name = "PessoasFisicas.findByCpf", query = "SELECT p FROM PessoasFisicas p WHERE p.cpf = :cpf"),
    @NamedQuery(name = "PessoasFisicas.findByEndereco", query = "SELECT p FROM PessoasFisicas p WHERE p.endereco = :endereco"),
    @NamedQuery(name = "PessoasFisicas.findByTelefone", query = "SELECT p FROM PessoasFisicas p WHERE p.telefone = :telefone"),
    @NamedQuery(name = "PessoasFisicas.findByEmail", query = "SELECT p FROM PessoasFisicas p WHERE p.email = :email")})
public class PessoasFisicas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_pessoa_fisica")
    private Integer idPessoaFisica;
    @Basic(optional = false)
    @Column(name = "nome")
    private String nome;
    @Basic(optional = false)
    @Column(name = "cpf")
    private String cpf;
    @Column(name = "endereco")
    private String endereco;
    @Column(name = "telefone")
    private String telefone;
    @Column(name = "email")
    private String email;
    @OneToMany(mappedBy = "idPessoaFisica")
    private Collection<Movimentos> movimentosCollection;
    @OneToMany(mappedBy = "idPessoaFisica")
    private Collection<Pessoa> pessoaCollection;

    public PessoasFisicas() {
    }

    public PessoasFisicas(Integer idPessoaFisica) {
        this.idPessoaFisica = idPessoaFisica;
    }

    public PessoasFisicas(Integer idPessoaFisica, String nome, String cpf) {
        this.idPessoaFisica = idPessoaFisica;
        this.nome = nome;
        this.cpf = cpf;
    }

    public Integer getIdPessoaFisica() {
        return idPessoaFisica;
    }

    public void setIdPessoaFisica(Integer idPessoaFisica) {
        this.idPessoaFisica = idPessoaFisica;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Collection<Movimentos> getMovimentosCollection() {
        return movimentosCollection;
    }

    public void setMovimentosCollection(Collection<Movimentos> movimentosCollection) {
        this.movimentosCollection = movimentosCollection;
    }

    public Collection<Pessoa> getPessoaCollection() {
        return pessoaCollection;
    }

    public void setPessoaCollection(Collection<Pessoa> pessoaCollection) {
        this.pessoaCollection = pessoaCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPessoaFisica != null ? idPessoaFisica.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
 
        if (!(object instanceof PessoasFisicas)) {
            return false;
        }
        PessoasFisicas other = (PessoasFisicas) object;
        if ((this.idPessoaFisica == null && other.idPessoaFisica != null) || (this.idPessoaFisica != null && !this.idPessoaFisica.equals(other.idPessoaFisica))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.PessoasFisicas[ idPessoaFisica=" + idPessoaFisica + " ]";
    }
    
}
