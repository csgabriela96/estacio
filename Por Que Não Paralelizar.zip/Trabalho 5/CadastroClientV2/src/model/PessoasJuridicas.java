/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Gabriela
 */
@Entity
@Table(name = "pessoas_juridicas")
@NamedQueries({
    @NamedQuery(name = "PessoasJuridicas.findAll", query = "SELECT p FROM PessoasJuridicas p"),
    @NamedQuery(name = "PessoasJuridicas.findByIdPessoaJuridica", query = "SELECT p FROM PessoasJuridicas p WHERE p.idPessoaJuridica = :idPessoaJuridica"),
    @NamedQuery(name = "PessoasJuridicas.findByNomeFantasia", query = "SELECT p FROM PessoasJuridicas p WHERE p.nomeFantasia = :nomeFantasia"),
    @NamedQuery(name = "PessoasJuridicas.findByRazaoSocial", query = "SELECT p FROM PessoasJuridicas p WHERE p.razaoSocial = :razaoSocial"),
    @NamedQuery(name = "PessoasJuridicas.findByCnpj", query = "SELECT p FROM PessoasJuridicas p WHERE p.cnpj = :cnpj"),
    @NamedQuery(name = "PessoasJuridicas.findByEndereco", query = "SELECT p FROM PessoasJuridicas p WHERE p.endereco = :endereco"),
    @NamedQuery(name = "PessoasJuridicas.findByTelefone", query = "SELECT p FROM PessoasJuridicas p WHERE p.telefone = :telefone"),
    @NamedQuery(name = "PessoasJuridicas.findByEmail", query = "SELECT p FROM PessoasJuridicas p WHERE p.email = :email")})
public class PessoasJuridicas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_pessoa_juridica")
    private Integer idPessoaJuridica;
    @Column(name = "nome_fantasia")
    private String nomeFantasia;
    @Basic(optional = false)
    @Column(name = "razao_social")
    private String razaoSocial;
    @Basic(optional = false)
    @Column(name = "cnpj")
    private String cnpj;
    @Column(name = "endereco")
    private String endereco;
    @Column(name = "telefone")
    private String telefone;
    @Column(name = "email")
    private String email;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idPessoaJuridica")
    private Collection<Movimentos> movimentosCollection;
    @JoinColumn(name = "id_movimento", referencedColumnName = "id_movimento")
    @ManyToOne
    private Movimentos idMovimento;
    @OneToMany(mappedBy = "idPessoaJuridica")
    private Collection<Pessoa> pessoaCollection;

    public PessoasJuridicas() {
    }

    public PessoasJuridicas(Integer idPessoaJuridica) {
        this.idPessoaJuridica = idPessoaJuridica;
    }

    public PessoasJuridicas(Integer idPessoaJuridica, String razaoSocial, String cnpj) {
        this.idPessoaJuridica = idPessoaJuridica;
        this.razaoSocial = razaoSocial;
        this.cnpj = cnpj;
    }

    public Integer getIdPessoaJuridica() {
        return idPessoaJuridica;
    }

    public void setIdPessoaJuridica(Integer idPessoaJuridica) {
        this.idPessoaJuridica = idPessoaJuridica;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Collection<Movimentos> getMovimentosCollection() {
        return movimentosCollection;
    }

    public void setMovimentosCollection(Collection<Movimentos> movimentosCollection) {
        this.movimentosCollection = movimentosCollection;
    }

    public Movimentos getIdMovimento() {
        return idMovimento;
    }

    public void setIdMovimento(Movimentos idMovimento) {
        this.idMovimento = idMovimento;
    }

    public Collection<Pessoa> getPessoaCollection() {
        return pessoaCollection;
    }

    public void setPessoaCollection(Collection<Pessoa> pessoaCollection) {
        this.pessoaCollection = pessoaCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPessoaJuridica != null ? idPessoaJuridica.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof PessoasJuridicas)) {
            return false;
        }
        PessoasJuridicas other = (PessoasJuridicas) object;
        if ((this.idPessoaJuridica == null && other.idPessoaJuridica != null) || (this.idPessoaJuridica != null && !this.idPessoaJuridica.equals(other.idPessoaJuridica))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.PessoasJuridicas[ idPessoaJuridica=" + idPessoaJuridica + " ]";
    }
    
}
