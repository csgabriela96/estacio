package cadastroserver;

import controller.ProdutoJpaController;
import controller.UsuarioJpaController;
import model.Produto;
import model.Usuario;
import java.io.*;
import java.net.Socket;
import java.util.List;

public class CadastroThread extends Thread {
    private ProdutoJpaController ctrl;    
    private UsuarioJpaController ctrlUsu; 
    private Socket s1;                    

    public CadastroThread(ProdutoJpaController ctrl, UsuarioJpaController ctrlUsu, Socket s1) {
        this.ctrl = ctrl;
        this.ctrlUsu = ctrlUsu;
        this.s1 = s1;
    }

    @Override
    public void run() {
        try {
            ObjectOutputStream out = new ObjectOutputStream(s1.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(s1.getInputStream());

            String login = (String) in.readObject();
            String senha = (String) in.readObject();

            System.out.println("Cliente tentando login: " + login);

            Usuario usuario = ctrlUsu.findUsuario(login, senha);
            if (usuario == null) {
                out.writeObject("Credenciais inválidas. Conexão encerrada.");
                s1.close();
                return;
            }

            out.writeObject("Login bem-sucedido! Digite 'L' para listar produtos.");

            while (true) {
                String comando = (String) in.readObject();

                if ("L".equalsIgnoreCase(comando)) {
                    List<Produto> produtos = ctrl.findProdutoEntities();

                    out.writeObject(produtos);
                } else {
                    out.writeObject("Comando inválido.");
                }
            }

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Erro na comunicação: " + e.getMessage());
        } finally {
            try {
                s1.close();
            } catch (IOException e) {
                System.out.println("Erro ao fechar o socket: " + e.getMessage());
            }
        }
    }
}
