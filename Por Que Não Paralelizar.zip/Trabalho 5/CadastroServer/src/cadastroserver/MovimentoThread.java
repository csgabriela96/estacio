package cadastroserver;

import java.io.*;
import java.net.Socket;
import java.math.BigDecimal;
import javax.persistence.EntityManagerFactory;
import controller.ProdutoJpaController;
import controller.UsuarioJpaController;
import controller.MovimentosJpaController;
import controller.PessoaJpaController;
import model.Produto;
import model.Movimentos;
import model.PessoasFisicas;
import model.PessoasJuridicas;

public class MovimentoThread extends Thread {
    private Socket socket;
    private MovimentosJpaController ctrlMov;
    private ProdutoJpaController ctrlProd;
    private PessoaJpaController ctrlPessoa;
    private UsuarioJpaController ctrlUsuario;

    public MovimentoThread(Socket socket, MovimentosJpaController ctrlMov, ProdutoJpaController ctrlProd, 
                           PessoaJpaController ctrlPessoa, UsuarioJpaController ctrlUsuario) {
        this.socket = socket;
        this.ctrlMov = ctrlMov;
        this.ctrlProd = ctrlProd;
        this.ctrlPessoa = ctrlPessoa;
        this.ctrlUsuario = ctrlUsuario;
    }

    @Override
    public void run() {
        try {
            System.out.println("Thread iniciada para: " + socket.getInetAddress());

            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

            System.out.println("Streams criadas, aguardando comando...");

            String command = (String) in.readObject();
            if (!command.equals("E") && !command.equals("S")) {
                out.writeObject("Comando inválido! Use 'E' para entrada ou 'S' para saída.");
                out.flush();
                return;
            }

            int idPessoa = (int) in.readObject();
            int idProduto = (int) in.readObject();
            int quantidade = (int) in.readObject();
            String valorStr = (String) in.readObject();
            BigDecimal valorUnitario = new BigDecimal(valorStr);
            int idUsuario = (int) in.readObject();

            Movimentos movimento = new Movimentos();
            movimento.setTipoMovimento(command);

            var usuario = ctrlUsuario.findUsuarioById(idUsuario);
            if (usuario == null) {
                out.writeObject("Erro: Usuário não encontrado!");
                out.flush();
                return;
            }
            movimento.setIdUsuario(usuario);

            PessoasJuridicas pessoaJuridica = ctrlPessoa.findPessoaJuridica(idPessoa);
            PessoasFisicas pessoaFisica = ctrlPessoa.findPessoaFisica(idPessoa);
            if (pessoaJuridica != null) {
                movimento.setIdPessoaJuridica(pessoaJuridica);
            } else if (pessoaFisica != null) {
                movimento.setIdPessoaFisica(pessoaFisica);
            } else {
                out.writeObject("Erro: Pessoa não encontrada com ID " + idPessoa);
                out.flush();
                return;
            }

            Produto produto = ctrlProd.findProduto(idProduto);
            if (produto == null) {
                out.writeObject("Erro: Produto não encontrado com ID " + idProduto);
                out.flush();
                return;
            }
            movimento.setIdProduto(produto);
            movimento.setQuantidade(quantidade);
            movimento.setPrecoUnitario(valorUnitario);

            ctrlMov.create(movimento);

            if (command.equals("E")) {
                produto.setQuantidade(produto.getQuantidade() + quantidade);
            } else {
                if (produto.getQuantidade() < quantidade) {
                    out.writeObject("Erro: Estoque insuficiente para retirada.");
                    out.flush();
                    return;
                }
                produto.setQuantidade(produto.getQuantidade() - quantidade);
            }
            ctrlProd.edit(produto);

            out.writeObject("Movimento registrado com sucesso!");
            out.flush();

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erro na comunicação: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Erro ao persistir dados: " + e.getMessage());
        }
    }
}
