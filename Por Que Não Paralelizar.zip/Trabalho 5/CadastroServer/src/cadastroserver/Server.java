package cadastroserver;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import controller.MovimentosJpaController;
import controller.ProdutoJpaController;
import controller.PessoaJpaController;
import controller.UsuarioJpaController;

public class Server {
    private static final int PORT = 4321;

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("CadastroServerPU");
        MovimentosJpaController ctrlMov = new MovimentosJpaController(emf);
        ProdutoJpaController ctrlProd = new ProdutoJpaController(emf);
        PessoaJpaController ctrlPessoa = new PessoaJpaController(emf);
        UsuarioJpaController ctrlUsuario = new UsuarioJpaController(emf);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Servidor iniciado na porta " + PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nova conexão recebida de " + clientSocket.getInetAddress());

                try {
                    ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                    ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());

                    out.writeObject("Bem-vindo ao servidor!");
                    out.flush();
                } catch (IOException e) {
                    System.err.println("Erro ao enviar mensagem ao cliente: " + e.getMessage());
                }

                MovimentoThread thread = new MovimentoThread(clientSocket, ctrlMov, ctrlProd, ctrlPessoa, ctrlUsuario);
                thread.start();
            }
        } catch (IOException e) {
            System.err.println("Erro no servidor: " + e.getMessage());
        }
    }
}
