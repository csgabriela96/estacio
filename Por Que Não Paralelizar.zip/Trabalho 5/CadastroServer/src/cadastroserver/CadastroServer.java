/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cadastroserver;

import controller.ProdutoJpaController;
import controller.UsuarioJpaController;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CadastroServer {

    public static void main(String[] args) {
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("SeuPU");

            ProdutoJpaController produtoCtrl = new ProdutoJpaController(emf);
            UsuarioJpaController usuarioCtrl = new UsuarioJpaController(emf);

            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Servidor rodando na porta 12345...");

            while (true) {
                Socket clienteSocket = serverSocket.accept();
                System.out.println("Novo cliente conectado!");

                CadastroThread thread = new CadastroThread(produtoCtrl, usuarioCtrl, clienteSocket);
                thread.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}