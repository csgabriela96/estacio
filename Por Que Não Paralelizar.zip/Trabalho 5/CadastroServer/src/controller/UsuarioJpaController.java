package controller;

import javax.persistence.*;
import java.util.List;
import model.Usuario;

public class UsuarioJpaController {
    private EntityManagerFactory emf;

    public UsuarioJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public Usuario findUsuarioById(int id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuario.class, id);
        } finally {
            em.close();
        }
    }

    public Usuario findUsuario(String email, String senha) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Usuario> query = em.createNamedQuery("Usuario.findByLogin", Usuario.class);
            query.setParameter("email", email);
            query.setParameter("senha", senha);

            List<Usuario> resultado = query.getResultList();
            return resultado.isEmpty() ? null : resultado.get(0);
        } finally {
            em.close();
        }
    }

    public List<Usuario> findUsuarioEntities() {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Usuario> query = em.createNamedQuery("Usuario.findAll", Usuario.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}
