/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Gabriela
 */
@Entity
@Table(name = "movimentos")
@NamedQueries({
    @NamedQuery(name = "Movimentos.findAll", query = "SELECT m FROM Movimentos m"),
    @NamedQuery(name = "Movimentos.findByIdMovimento", query = "SELECT m FROM Movimentos m WHERE m.idMovimento = :idMovimento"),
    @NamedQuery(name = "Movimentos.findByQuantidade", query = "SELECT m FROM Movimentos m WHERE m.quantidade = :quantidade"),
    @NamedQuery(name = "Movimentos.findByPrecoUnitario", query = "SELECT m FROM Movimentos m WHERE m.precoUnitario = :precoUnitario"),
    @NamedQuery(name = "Movimentos.findByDataMovimento", query = "SELECT m FROM Movimentos m WHERE m.dataMovimento = :dataMovimento"),
    @NamedQuery(name = "Movimentos.findByTipoMovimento", query = "SELECT m FROM Movimentos m WHERE m.tipoMovimento = :tipoMovimento")})
public class Movimentos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_movimento")
    private Integer idMovimento;
    @Basic(optional = false)
    @Column(name = "quantidade")
    private int quantidade;
    @Basic(optional = false)
    @Column(name = "preco_unitario")
    private BigDecimal precoUnitario;
    @Column(name = "data_movimento")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataMovimento;
    @Basic(optional = false)
    @Column(name = "tipo_movimento")
    private String tipoMovimento;
    @JoinColumn(name = "id_pessoa_fisica", referencedColumnName = "id_pessoa_fisica")
    @ManyToOne
    private PessoasFisicas idPessoaFisica;
    @JoinColumn(name = "id_pessoa_juridica", referencedColumnName = "id_pessoa_juridica")
    @ManyToOne(optional = false)
    private PessoasJuridicas idPessoaJuridica;
    @JoinColumn(name = "id_produto", referencedColumnName = "ID_Produto")
    @ManyToOne(optional = false)
    private Produto idProduto;
    @JoinColumn(name = "id_usuario", referencedColumnName = "ID_Usuario")
    @ManyToOne(optional = false)
    private Usuario idUsuario;
    @OneToMany(mappedBy = "idMovimento")
    private Collection<PessoasJuridicas> pessoasJuridicasCollection;
    @OneToMany(mappedBy = "idMovimento")
    private Collection<Produto> produtoCollection;

    public Movimentos() {
    }

    public Movimentos(Integer idMovimento) {
        this.idMovimento = idMovimento;
    }

    public Movimentos(Integer idMovimento, int quantidade, BigDecimal precoUnitario, String tipoMovimento) {
        this.idMovimento = idMovimento;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
        this.tipoMovimento = tipoMovimento;
    }

    public Integer getIdMovimento() {
        return idMovimento;
    }

    public void setIdMovimento(Integer idMovimento) {
        this.idMovimento = idMovimento;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public BigDecimal getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(BigDecimal precoUnitario) {
        this.precoUnitario = precoUnitario;
    }

    public Date getDataMovimento() {
        return dataMovimento;
    }

    public void setDataMovimento(Date dataMovimento) {
        this.dataMovimento = dataMovimento;
    }

    public String getTipoMovimento() {
        return tipoMovimento;
    }

    public void setTipoMovimento(String tipoMovimento) {
        this.tipoMovimento = tipoMovimento;
    }

    public PessoasFisicas getIdPessoaFisica() {
        return idPessoaFisica;
    }

    public void setIdPessoaFisica(PessoasFisicas idPessoaFisica) {
        this.idPessoaFisica = idPessoaFisica;
    }

    public PessoasJuridicas getIdPessoaJuridica() {
        return idPessoaJuridica;
    }

    public void setIdPessoaJuridica(PessoasJuridicas idPessoaJuridica) {
        this.idPessoaJuridica = idPessoaJuridica;
    }

    public Produto getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(Produto idProduto) {
        this.idProduto = idProduto;
    }

    public Usuario getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Usuario idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Collection<PessoasJuridicas> getPessoasJuridicasCollection() {
        return pessoasJuridicasCollection;
    }

    public void setPessoasJuridicasCollection(Collection<PessoasJuridicas> pessoasJuridicasCollection) {
        this.pessoasJuridicasCollection = pessoasJuridicasCollection;
    }

    public Collection<Produto> getProdutoCollection() {
        return produtoCollection;
    }

    public void setProdutoCollection(Collection<Produto> produtoCollection) {
        this.produtoCollection = produtoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idMovimento != null ? idMovimento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Movimentos)) {
            return false;
        }
        Movimentos other = (Movimentos) object;
        if ((this.idMovimento == null && other.idMovimento != null) || (this.idMovimento != null && !this.idMovimento.equals(other.idMovimento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Movimentos[ idMovimento=" + idMovimento + " ]";
    }
    
}
