/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cadastroclient;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.Scanner;
import model.Produto;
import java.io.EOFException;

public class CadastroClient {
    public static void main(String[] args) {
        try {

    Socket socket = new Socket("localhost", 4321);
    ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
    ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

    Scanner scanner = new Scanner(System.in);

    System.out.println("Servidor: " + in.readObject());
    System.out.print("Digite seu login: ");
    String login = scanner.nextLine();
    out.writeObject(login);
    out.flush();

    System.out.println("Servidor: " + in.readObject());
    System.out.print("Digite sua senha: ");
    String senha = scanner.nextLine();
    out.writeObject(senha);
    out.flush();

    Object resposta = in.readObject();
    if (resposta instanceof String) {
        String msg = (String) resposta;
        System.out.println("Servidor: " + msg);

        if (msg.contains("inválido")) {
            System.out.println("Encerrando conexão...");
            socket.close();
            return;
        }
    }

    out.writeObject("L");
    out.flush();

    Object obj = in.readObject();
    if (obj instanceof List) {
        List<String> produtos = (List<String>) obj;
        System.out.println("\nLista de produtos recebida:");
        for (String p : produtos) {
            System.out.println("Produto: " + p);
        }
    } else {
        System.out.println("Resposta inesperada do servidor.");
    }

    socket.close();
    System.out.println("Conexão encerrada.");
} catch (EOFException e) {
    System.out.println("O servidor fechou a conexão inesperadamente.");
} catch (Exception e) {
    e.printStackTrace();
}

}}
