/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastro.model.util;

/**
 *
 * @author Gabriela
 */
import java.sql.SQLException;
import java.util.List;
import cadastrobd.model.PessoaFisica;
import cadastrobd.model.PessoaJuridica;
import cadastro.model.util.PessoaJuridicaDAO;
import cadastro.model.util.PessoaFisicaDAO;
import cadastrobd.model.pessoa;
import java.util.Scanner;

public class CadastroBDTeste {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PessoaFisicaDAO pessoaFisicaDAO = new PessoaFisicaDAO();
        PessoaJuridicaDAO pessoaJuridicaDAO = new PessoaJuridicaDAO();

        while (true) {
            System.out.println("\n===== MENU =====");
            System.out.println("1 - Cadastrar Pessoa Física");
            System.out.println("2 - Alterar Pessoa Física");
            System.out.println("3 - Listar Pessoas Físicas");
            System.out.println("4 - Excluir Pessoa Física");
            System.out.println("5 - Cadastrar Pessoa Jurídica");
            System.out.println("6 - Alterar Pessoa Jurídica");
            System.out.println("7 - Listar Pessoas Jurídicas");
            System.out.println("8 - Excluir Pessoa Jurídica");
            System.out.println("9 - Sair");
            System.out.print("Escolha uma opção: ");
            
            int opcao = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (opcao) {
                    case 1 -> cadastrarPessoaFisica(scanner, pessoaFisicaDAO);
                    case 2 -> alterarPessoaFisica(scanner, pessoaFisicaDAO);
                    case 3 -> listarPessoasFisicas(pessoaFisicaDAO);
                    case 4 -> excluirPessoaFisica(scanner, pessoaFisicaDAO);
                    case 5 -> cadastrarPessoaJuridica(scanner, pessoaJuridicaDAO);
                    case 6 -> alterarPessoaJuridica(scanner, pessoaJuridicaDAO);
                    case 8 -> excluirPessoaJuridica(scanner, pessoaJuridicaDAO);
                    case 9 -> {
                        System.out.println("Saindo...");
                        scanner.close();
                        return;
                    }
                    default -> System.out.println("❌ Opção inválida!");
                }
            } catch (SQLException e) {
                System.out.println("❌ Erro no banco de dados: " + e.getMessage());
            }
        }
    }

    private static void cadastrarPessoaFisica(Scanner scanner, PessoaFisicaDAO dao) throws SQLException {
        PessoaFisica pf = new PessoaFisica();
        System.out.print("Nome: ");
        pf.setNome(scanner.nextLine());
        System.out.print("Endereco: ");
        pf.setEndereco(scanner.nextLine());
        System.out.print("Telefone: ");
        pf.setTelefone(scanner.nextLine());
        System.out.print("Email: ");
        pf.setEmail(scanner.nextLine());
        System.out.print("CPF: ");
        pf.setCpf(scanner.nextLine());

        dao.incluir(pf);
        System.out.println("✅ Pessoa Física cadastrada!");
    }

    private static void alterarPessoaFisica(Scanner scanner, PessoaFisicaDAO dao) throws SQLException {
        System.out.print("ID da Pessoa Física: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        PessoaFisica pf = dao.getPessoa(id);
        if (pf == null) {
            System.out.println("❌ Pessoa Física não encontrada!");
            return;
        }

        System.out.print("Novo telefone: ");
        pf.setTelefone(scanner.nextLine());
        System.out.print("Novo email: ");
        pf.setEmail(scanner.nextLine());

        dao.alterar(pf);
        System.out.println("✅ Pessoa Física alterada!");
    }

    private static void listarPessoasFisicas(PessoaFisicaDAO dao) throws SQLException {
        List<PessoaFisica> lista = dao.getPessoas();
        if (lista.isEmpty()) {
            System.out.println("📌 Nenhuma Pessoa Física cadastrada.");
        } else {
            for (PessoaFisica pf : lista) {
                System.out.println(pf);
            }
        }
    }

    private static void excluirPessoaFisica(Scanner scanner, PessoaFisicaDAO dao) throws SQLException {
        System.out.print("ID da Pessoa Física: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        dao.excluir(id);
        System.out.println("✅ Pessoa Física excluída!");
    }

    private static void cadastrarPessoaJuridica(Scanner scanner, PessoaJuridicaDAO dao) throws SQLException {
        PessoaJuridica pj = new PessoaJuridica();
        System.out.print("Nome: ");
        pj.setNome(scanner.nextLine());
        System.out.print("Endereco: ");
        pj.setEndereco(scanner.nextLine());
        System.out.print("Telefone: ");
        pj.setTelefone(scanner.nextLine());
        System.out.print("Email: ");
        pj.setEmail(scanner.nextLine());
        System.out.print("CNPJ: ");
        pj.setCnpj(scanner.nextLine());

        dao.incluir(pj);
        System.out.println("✅ Pessoa Jurídica cadastrada!");
    }

    private static void alterarPessoaJuridica(Scanner scanner, PessoaJuridicaDAO dao) throws SQLException {
        System.out.print("ID da Pessoa Jurídica: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        PessoaJuridica pj = dao.getPessoa(id);
        if (pj == null) {
            System.out.println("❌ Pessoa Jurídica não encontrada!");
            return;
        }

        System.out.print("Novo telefone: ");
        pj.setTelefone(scanner.nextLine());
        System.out.print("Novo email: ");
        pj.setEmail(scanner.nextLine());

        dao.alterar(pj);
        System.out.println("✅ Pessoa Jurídica alterada!");
    }

    private static void excluirPessoaJuridica(Scanner scanner, PessoaJuridicaDAO dao) throws SQLException {
        System.out.print("ID da Pessoa Jurídica: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        dao.excluir(id);
        System.out.println("✅ Pessoa Jurídica excluída!");
    }
}
