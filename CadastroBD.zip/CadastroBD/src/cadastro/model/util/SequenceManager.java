/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastro.model.util;

/**
 *
 * @author Gabriela
 */
import java.sql.*;

public class SequenceManager {
    public static long getValue(String sequenceName) throws SQLException {
        String sql = "SELECT NEXT VALUE FOR " + sequenceName;
        ResultSet rs = null;
        Connection conn = null;
        Statement stmt = null;
        long nextValue = -1;

        try {
            conn = ConectorBD.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                nextValue = rs.getLong(1);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao obter o próximo valor da sequência: " + e.getMessage());
            throw e;
        } finally {
            ConectorBD.close(rs);
            ConectorBD.close(stmt);
            ConectorBD.close(conn);
        }

        return nextValue;
    }
}