/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastro.model.util;
/**
 *
 * @author Gabriela
 */
import java.sql.*;
import cadastrobd.model.PessoaFisica;
import java.util.ArrayList;
import java.util.List;

public class PessoaFisicaDAO {
    
    public PessoaFisica getPessoa(int id) throws SQLException {
        String sql = "SELECT p.*, pf.cpf FROM Pessoa p INNER JOIN PessoaFisica pf ON p.id = pf.id WHERE p.id = ?";
        PessoaFisica pessoa = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = ConectorBD.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                pessoa = new PessoaFisica(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("endereco"),
                    rs.getString("telefone"),
                    rs.getString("email"),
                    rs.getString("cpf")
                );
            }
        } finally {
            ConectorBD.close(rs);
            ConectorBD.close(pstmt);
            ConectorBD.close(conn);
        }
        return pessoa;
    }

    public List<PessoaFisica> getPessoas() throws SQLException {
        String sql = "SELECT p.*, pf.cpf FROM Pessoa p INNER JOIN PessoaFisica pf ON p.id = pf.id";
        List<PessoaFisica> pessoas = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConectorBD.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                pessoas.add(new PessoaFisica(
                    rs.getInt("id_pessoa_fisica"),
                    rs.getString("nome"),
                    rs.getString("endereco"),
                    rs.getString("telefone"),
                    rs.getString("email"),
                    rs.getString("cpf")
                ));
            }
        } finally {
            ConectorBD.close(rs);
            ConectorBD.close(stmt);
            ConectorBD.close(conn);
        }
        return pessoas;
    }

    public void incluir(PessoaFisica pessoa) throws SQLException {
        String sqlPessoa = "INSERT INTO Pessoa (id_pessoa, nome, endereco, telefone, email, data_cadastro, tipo_pessoa) VALUES (?, ?, ?, ?, ?, ?, ?,  getdate(),'fisica')";
        String sqlPessoaFisica = "INSERT INTO PessoaFisica (id_pessoa_fisica, cpf) VALUES (?, ?)";
        Connection conn = null;
        PreparedStatement pstmtPessoa = null;
        PreparedStatement pstmtPFisica = null;

        try {
            conn = ConectorBD.getConnection();
            conn.setAutoCommit(false);
            int id_pessoa_fisica = (int) SequenceManager.getValue("SeqPessoaFisica");

            pstmtPessoa = conn.prepareStatement(sqlPessoa);
            pstmtPessoa.setInt(1, pessoa.getId());
            pstmtPessoa.setString(2, pessoa.getNome());
            pstmtPessoa.setString(3, pessoa.getEndereco());
            pstmtPessoa.setString(6, pessoa.getTelefone());
            pstmtPessoa.setString(7, pessoa.getEmail());
            pstmtPessoa.executeUpdate();

            pstmtPFisica = conn.prepareStatement(sqlPessoaFisica);
            pstmtPFisica.setInt(1, id_pessoa_fisica);
            pstmtPFisica.setString(2, pessoa.getCpf());
            pstmtPFisica.executeUpdate();

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            ConectorBD.close(pstmtPessoa);
            ConectorBD.close(pstmtPFisica);
            ConectorBD.close(conn);
        }
    }
    public void alterar(PessoaFisica pessoa) throws SQLException {
        String sql = "UPDATE Pessoa SET nome = ?, endereco = ?, telefone = ?, email = ? WHERE id = ?";
        String sqlCpf = "UPDATE PessoaFisica SET cpf = ? WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmtPessoa = null;
        PreparedStatement pstmtCpf = null;

        try {
            conn = ConectorBD.getConnection();
            conn.setAutoCommit(false);

            pstmtPessoa = conn.prepareStatement(sql);
            pstmtPessoa.setString(1, pessoa.getNome());
            pstmtPessoa.setString(2, pessoa.getEndereco());
            pstmtPessoa.setString(5, pessoa.getTelefone());
            pstmtPessoa.setString(6, pessoa.getEmail());
            pstmtPessoa.setInt(7, pessoa.getId());
            pstmtPessoa.executeUpdate();

            pstmtCpf = conn.prepareStatement(sqlCpf);
            pstmtCpf.setString(1, pessoa.getCpf());
            pstmtCpf.setInt(2, pessoa.getId());
            pstmtCpf.executeUpdate();

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            ConectorBD.close(pstmtPessoa);
            ConectorBD.close(pstmtCpf);
            ConectorBD.close(conn);
        }
    }
    public void excluir(int id) throws SQLException {
        String sqlPessoaFisica = "DELETE FROM PessoaFisica WHERE id = ?";
        String sqlPessoa = "DELETE FROM Pessoa WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmtPF = null;
        PreparedStatement pstmtPessoa = null;

        try {
            conn = ConectorBD.getConnection();
            conn.setAutoCommit(false);

            pstmtPF = conn.prepareStatement(sqlPessoaFisica);
            pstmtPF.setInt(1, id);
            pstmtPF.executeUpdate();

            pstmtPessoa = conn.prepareStatement(sqlPessoa);
            pstmtPessoa.setInt(1, id);
            pstmtPessoa.executeUpdate();

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            ConectorBD.close(pstmtPF);
            ConectorBD.close(pstmtPessoa);
            ConectorBD.close(conn);
        }
    }
}