/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastro.model.util;

/**
 *
 * @author Gabriela
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import cadastrobd.model.PessoaJuridica;


public class PessoaJuridicaDAO {
    public void incluir(PessoaJuridica pessoa) throws SQLException {
        Connection conn = ConectorBD.getConnection();
        try {
int id = (int) SequenceManager.getValue("pessoa_seq");
            pessoa.setId(id);

            String sqlPessoa = "INSERT INTO Pessoa (id, nome, endereco, telefone, email) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPessoa)) {
                stmt.setInt(1, id);
                stmt.setString(2, pessoa.getNome());
                stmt.setString(3, pessoa.getEndereco());
                stmt.setString(6, pessoa.getTelefone());
                stmt.setString(7, pessoa.getEmail());
                stmt.executeUpdate();
            }

            String sqlPessoaJuridica = "INSERT INTO PessoaJuridica (id, cnpj) VALUES (?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPessoaJuridica)) {
                stmt.setInt(1, id);
                stmt.setString(2, pessoa.getCnpj());
                stmt.executeUpdate();
            }
        } finally {
            ConectorBD.close(conn);
        }
    }

    public void alterar(PessoaJuridica pessoa) throws SQLException {
        Connection conn = ConectorBD.getConnection();
        try {
            String sql = "UPDATE Pessoa SET nome=?, endereco=?, telefone=?, email=? WHERE id=?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, pessoa.getNome());
                stmt.setString(2, pessoa.getEndereco());
                stmt.setString(5, pessoa.getTelefone());
                stmt.setString(6, pessoa.getEmail());
                stmt.setInt(7, pessoa.getId());
                stmt.executeUpdate();
            }
        } finally {
            ConectorBD.close(conn);
        }
    }

    public void excluir(int id) throws SQLException {
        Connection conn = ConectorBD.getConnection();
        try {
            String sqlPessoaJuridica = "DELETE FROM PessoaJuridica WHERE id=?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPessoaJuridica)) {
                stmt.setInt(1, id);
                stmt.executeUpdate();
            }

            String sqlPessoa = "DELETE FROM Pessoa WHERE id=?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPessoa)) {
                stmt.setInt(1, id);
                stmt.executeUpdate();
            }
        } finally {
            ConectorBD.close(conn);
        }
    }

    public PessoaJuridica getPessoa(int id) throws SQLException {
    Connection conn = ConectorBD.getConnection();
    PessoaJuridica pessoaJuridica = null;
    try {
        String sql = "SELECT p.id, p.nome, p.endereco, p.telefone, p.email, pj.cnpj " +
                     "FROM Pessoa p " +
                     "JOIN PessoaJuridica pj ON p.id = pj.id " +
                     "WHERE p.id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id); // Passa o ID da pessoa jurídica para a consulta
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    pessoaJuridica = new PessoaJuridica(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("endereco"),
                        rs.getString("telefone"),
                        rs.getString("email"),
                        rs.getString("cnpj")
                    );
                }
            }
        }
    } finally {
        ConectorBD.close(conn);
    }
    return pessoaJuridica;
}
}