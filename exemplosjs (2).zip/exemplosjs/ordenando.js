const swap = (array, position1, position2) => {
    [array[position1], array[position2]] = [array[position2], array[position1]];
};

const shuffle = (array) => {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        swap(array, i, j);
    }
};

const bubble_sort = (array) => {
    const n = array.length;

    for (let i = 0; i < n - 1; i++) {
        for (let j = 0; j < n - i - 1; j++) {
            if (array[j] > array[j + 1]) {
                swap(array, j, j + 1);
            }
        }
    }
};

const selection_sort = (array) => {
    const n = array.length;

    for (let i = 0; i < n - 1; i++) {
        let minIndex = i;
        for (let j = i + 1; j < n; j++) {
            if (array[j] < array[minIndex]) {
                minIndex = j;
            }
        }
        swap(array, i, minIndex);
    }
};

const particionamento = (array, inicio, fim) => {
    const pivot = array[Math.floor((inicio + fim) / 2)];
    let i = inicio;
    let j = fim;

    while (i <= j) {
        while (array[i] < pivot) {
            i++;
        }
        while (array[j] > pivot) {
            j--;
        }
        if (i <= j) {
            swap(array, i, j);
            i++;
            j--;
        }
    }

    return i;
};

const quick_sort = (array, inicio = 0, fim = array.length - 1) => {
    if (inicio < fim) {
        const index = particionamento(array, inicio, fim);

        quick_sort(array, inicio, index - 1);
        quick_sort(array, index, fim);
    }
};
